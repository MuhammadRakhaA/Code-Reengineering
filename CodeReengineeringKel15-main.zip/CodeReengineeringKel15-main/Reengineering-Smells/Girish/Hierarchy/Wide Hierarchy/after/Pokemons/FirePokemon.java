package Wide_Hierrarchy.Pokemons;

import ...

public class FirePokemon {
	
	public FirePokemon(String name, String sprite, int health, int speed, Arraylist<Move> moveSet) {
		super(name, sprite, health, new Fire(), speed, moveSet)
	}
}
