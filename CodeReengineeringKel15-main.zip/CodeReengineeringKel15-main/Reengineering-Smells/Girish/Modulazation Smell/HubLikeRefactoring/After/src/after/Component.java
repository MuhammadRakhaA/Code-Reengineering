package after;

interface Component {
    void send(String message);
    void receive(String message);
}