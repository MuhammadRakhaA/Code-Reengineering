/**
 * 
 */
/**
 * @author Nitro5
 *
 */
module Middleman {
}