
public class main {
	public static String name = "John Miller";
	public static int salary = 11000;
	public static void Main(String[] args) {
		
		System.out.println(name + "'s salary is" + salary);
	}
}