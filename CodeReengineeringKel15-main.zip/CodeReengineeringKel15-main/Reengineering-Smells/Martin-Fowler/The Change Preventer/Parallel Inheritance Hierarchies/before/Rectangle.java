

public class Rectangle extends Shape2D {

}