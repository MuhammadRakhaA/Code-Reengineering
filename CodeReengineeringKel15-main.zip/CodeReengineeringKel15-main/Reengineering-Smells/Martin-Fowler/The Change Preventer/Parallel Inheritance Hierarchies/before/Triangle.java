

public class Triangle extends Shape2D {

}