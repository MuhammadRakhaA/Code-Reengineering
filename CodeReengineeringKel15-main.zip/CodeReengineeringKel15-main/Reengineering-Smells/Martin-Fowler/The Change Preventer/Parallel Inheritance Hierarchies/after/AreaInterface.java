

public interface AreaInterface {
	public float area();
}
