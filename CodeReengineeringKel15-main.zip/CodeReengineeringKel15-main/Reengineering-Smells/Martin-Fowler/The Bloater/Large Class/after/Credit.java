
public class Credit {
	private int credit;

	public Credit() {
	}

	public int getCredit() {
		return credit;
	}

	public void setCredit(int credit) {
		this.credit = credit;
	}

	
}