
public class Menu {
    
	public void printDetails(String name, int age, Credit credit) {
        System.out.println("Name: " + name);
        System.out.println("Age: " + age);
        System.out.println("Credit: " + credit.getCredit());
    }
}
