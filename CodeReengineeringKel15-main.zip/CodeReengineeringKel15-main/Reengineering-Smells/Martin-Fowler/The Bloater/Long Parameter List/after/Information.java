public class Information{
    String name;
    String email;
    int amount;
    int current;

    public Information(String name, String email, int amount, int current){
        this.name = name;
        this.email = email;
        this.amount = amount;
        this.current = current;
    }
}