
public class Main {

	public Main() {
		new Menu().showMenu();
	}
	
	public static void main(String[] args) {
		new Main();
	}

}
