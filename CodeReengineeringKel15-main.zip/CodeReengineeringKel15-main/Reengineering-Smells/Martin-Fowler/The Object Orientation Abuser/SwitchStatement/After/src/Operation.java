package After.src;

public interface Operation {
    void perform();

    String pilihanOperasi(); 
}
